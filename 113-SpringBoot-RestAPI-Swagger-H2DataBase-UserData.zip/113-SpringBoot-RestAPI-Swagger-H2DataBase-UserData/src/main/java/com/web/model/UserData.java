package com.web.model;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.Data;

@Data
@Entity
@Schema(description = "User entity")
public class UserData {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Schema(description = "Unique Identifier of the User",example="1")
	
	private Integer id;
	@Schema(description = "Username",example="sriman")
	private String name;
	 
	@Schema(description = "User Coursename",example="java")
	private String course;
	
	@Schema(description = "User Email address",example="sriman@gmail.com")
	private String email;

	public UserData() {
		super();
		// TODO Auto-generated constructor stub
	}

	public UserData(Integer id, String name, String course, String email) {
		super();
		this.id = id;
		this.name = name;
		this.course = course;
		this.email = email;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getCourse() {
		return course;
	}

	public void setCourse(String course) {
		this.course = course;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	@Override
	public String toString() {
		return "UserData [id=" + id + ", name=" + name + ", course=" + course + ", email=" + email + "]";
	}
	
	
	

}
