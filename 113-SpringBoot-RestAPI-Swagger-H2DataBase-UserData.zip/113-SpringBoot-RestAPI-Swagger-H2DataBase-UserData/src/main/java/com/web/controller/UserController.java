package com.web.controller;

import java.util.List;

import org.apache.catalina.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.annotation.JacksonInject.Value;
import com.web.model.UserData;
import com.web.repository.UserRepo;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;

@RestController
@RequestMapping("/Userapp")

public class UserController {
	
	@Autowired UserRepo repo;
	
	@Operation(summary = "This is Test Method")
	@ApiResponse(responseCode = "200",description = "test method is tested successfully")
    @GetMapping("/test")
	public String testPage()
	{
		return "Welcome To RESTAPI Application With Swagger"; 
	}
	
	@Operation(summary = "saveNewUserApp",description = "now user Data Save With This End Point")
	@ApiResponse(responseCode = "200",description = "New User Added Successfully")
    @PostMapping("/save")
	public UserData saveUser(@RequestBody UserData userdata)
	
	{
		System.out.println("received User Data:"+userdata);
		return repo.save(userdata); 
	}
	
	@Operation(summary = "Get User By Id",description = "Display Single User Data")
	
	@ApiResponses(value = 
           {
	            @ApiResponse(responseCode = "200",description = "One User Data Retrieved"),
	
	            @ApiResponse(responseCode = "404",description = "User Not Found")
           })
    @GetMapping("/get{id}")
	public UserData getUser(@PathVariable int id)
	{
		UserData getOne=repo.findById(id) .get();
		return getOne; 
	}
	
	@Operation(summary = "Get All User",description = "Display All User Data In List")
	
	@ApiResponses(value =  {
			@ApiResponse(responseCode = "200",description = "All User Data Retrieved"),
			@ApiResponse(responseCode = "404",description = "User Not Found")
	})

	@GetMapping("/getAll")
	public List<UserData> getOne()
	{
		List<UserData> getOne=repo.findAll();
		return getOne;
	}
}
